function [ result ] = addprimes( s, e )
    z = s:e;
    result = sum(z(isprime(z)));
end

