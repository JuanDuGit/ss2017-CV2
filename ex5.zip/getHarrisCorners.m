function [score, points] = getHarrisCorners(I, sigma, kappa, theta)

[M11, M12, M22] = getM(I, sigma);

% TODO: compute score using det and trace

% TODO: display score

% TODO: find corners (variable points)

end